# FreshGreeneryApp
In modern age, the value of Vegetable Fruit Delivery App is growing up day by day, customer needs a simple interface to order vegetable fruit online, this major android project provide all the requirements of customer and it provides an easy interface to navigate. We have developed this Vegetable Fruit Delivery Application in android studio using java language and its native android app. 

I have developed this major project Vegetable Fruit Delivery on android Platform and it runs over the android studio. The main aim of this android project Vegetable Fruit Delivery is to manage all the details about customer, Vegetable, orders etc. In this project customer can buy Vegetable, make payment, and see the order history etc. In this project, we have developed 2 types of interfaces, one is for customer that is Android Application on Vegetable Fruit Delivery and another is Vegetable Fruit Delivery web api for admin. This project Android project on Vegetable Fruit Delivery manage all of the shopping features, like Vegetables details, add to cart, search Vegetable, payment, order history etc, also we developed android project UI very simple from which user can easily navigate through the pages.


## Types of User
1. Admin User :
  Admin user have all rights to managing all of Vegetables displaying in Vegetable Fruit Delivery android app on user mobile. He will be able to manage all shopping Vegetables, customers and orders
2. Customer User :
 The customer interface has been designed in Android Studio, from where customer can register, login and order Vegetables.
 
 
 ## Admin User functionalities
  * Login For Admin
  * Logout Functionality
  * Dashboard for Admin User
  * **Manage Vegetables**
    - Adding New Vegetables
    - Edit the Exitinng Vegetables
    - View details of the Vegetables
    - Listing of all Vegetables
  * **Manage Orders**  
    - See list of all orders
    - Update status of orders
  * **Reports of the project App**    
    - Report of all Orders
    - Report of all Vegetables
    
    
  ## Customer User functionalities
  * Login For Customer
  * Logout Functionality
  * Customer Registration
  * Customer My Account
  * Customer can search get the list of Vegetables
  * All avilable Vegetable category
  * Customer can see the Vegetable details with iamges
  * Customer can add/delete Vegetables from cart with quantity
  * Customer will be able to pay online or use Cash on delivery option
  * Customer can see his all order history and order items
  

# Techologies 
Android XML : Page layout has been designed in Android XML.
Android : This project has been developed over the Android Platform.
Java : All the coding has been written in Java.
Firebase : Firebase databse is used for this project.
Android Studio : We have used Android Studio for developing the project
