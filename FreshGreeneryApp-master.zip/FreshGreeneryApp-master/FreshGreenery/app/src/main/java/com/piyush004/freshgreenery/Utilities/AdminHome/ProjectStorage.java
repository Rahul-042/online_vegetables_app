package com.piyush004.freshgreenery.Utilities.AdminHome;

public class ProjectStorage {

    public static String UserName = " ";

}
